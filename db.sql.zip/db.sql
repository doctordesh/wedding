# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 91.212.209.146 (MySQL 5.5.43-0ubuntu0.14.04.1)
# Database: wedding
# Generation Time: 2015-07-30 19:14:31 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table invite_members
# ------------------------------------------------------------

DROP TABLE IF EXISTS `invite_members`;

CREATE TABLE `invite_members` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `invite_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `accepted` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `allergies` varchar(255) DEFAULT NULL,
  `speech` varchar(255) DEFAULT NULL,
  `relation` varchar(255) DEFAULT '',
  `time` varchar(255) DEFAULT NULL,
  `gear` varchar(255) DEFAULT NULL,
  `misc` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invite_id` (`invite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `invite_members` WRITE;
/*!40000 ALTER TABLE `invite_members` DISABLE KEYS */;

INSERT INTO `invite_members` (`id`, `invite_id`, `name`, `accepted`, `message`, `allergies`, `speech`, `relation`, `time`, `gear`, `misc`, `created_at`, `updated_at`)
VALUES
	(1,1,'Marie Juhlin','ACCEPTED','Jag anmäler mig med stor ödmjukhet över att få delta och tar inget för självklart, men uppskattar inbjudan och med stor ära deltager på er dag.','','SPEACH','mor din','en liten stund.....','näsduk','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(2,1,'Micke Juhlin','ACCEPTED','Ska bli väldigt trevligt att närvara vid ert bröllop','','DECLINED','Mamma Maries Man','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(3,2,'Mats Lunnergård','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(4,2,'Terese Sturesson','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(5,3,'Filip Lunnergård','ACCEPTED','','mot tråkigheter','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(6,4,'Olivia Lunnergård','ACCEPTED','Klart vi kommer! Ni är bäst!','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(7,4,'Oskar Nolhage','ACCEPTED','Klart vi kommer! Ni är bäst!','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(8,5,'Louise Juhlin','ACCEPTED','','kiwi','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(9,6,'Anton Juhlin','ACCEPTED','','','DECLINED','Styvbrorsa','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(10,6,'Pernilla Nordgren','ACCEPTED','','sockerärtor','DECLINED','Styvbrorsans flickvän','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(11,7,'Gun-Inger Lunnergård','ACCEPTED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(12,7,'Hans Nilsson','ACCEPTED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(13,8,'Kristina Gustavsson','ACCEPTED','','','SPEACH','god (Emils faster)','','min man','Det där med tal är lite osäkert och sker ev tillsammans med annan släkt','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(14,8,'Martin Gustavsson','ACCEPTED','','','SPEACH','god (Emils fasters man)','','min fru','Det där med tal är lite osäkert och sker ev tillsammans med annan släkt','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(15,9,'Matilda Gustavsson','ACCEPTED','Ser mycket fram emot det här<3','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(16,9,'Joachim Sundell','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(17,10,'Oskar Gustavsson','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(18,11,'Gunilla Gunnarsson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(19,11,'Tomas Gunnarsson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(20,12,'Lina Gunnarsson','ACCEPTED','Ledsen för sent svar men otroligt glad att jag får komma på er härliga fest! Puss','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(21,13,'Julia Lunnergård','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(22,13,'Oskar Lunnergård','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(23,14,'Carl Einarsson','ACCEPTED','Härligt JoE! Visst kommer jag, finns inget annat. Väldigt glad att bli bjuden. Kram!','Huliganer','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(24,14,'Maria Einarsson','ACCEPTED','Vi är väldigt glada för att vi får komma!','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(25,15,'Viktor Einarsson','ACCEPTED','Wihoo! Riktigt snygg sida!','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(26,15,'Julia Bjuremo','ACCEPTED','Vad kul det ska bli! :)','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(27,16,'Gurney Ekström','ACCEPTED','','','SPEACH','mormor','10 min','Nej','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(28,17,'Mona Olofsson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(29,17,'Bengt Olofsson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(30,18,'Marcus Olofsson','ACCEPTED','','','DECLINED','Kusin till Emil','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(31,19,'Fredrik Ekström','ACCEPTED','nej','','DECLINED','kusin till emil','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(32,20,'Annelie Ekström','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(33,21,'Jens Ekström','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(34,21,'Paula Ekström','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(35,22,'Åsa Eriksson','ACCEPTED','','','DECLINED','Emils moster','','','Sååå kul att få komma!!!','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(36,22,'Mattias Eriksson','ACCEPTED','','','DECLINED','gift med Emils moster','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(37,23,'Ulf Ekström','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(38,24,'Emelie Olofsson','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(39,25,'Johanna Olofsson','ACCEPTED','','Laktosintolerant','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(40,25,'Robin Ingvarsson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(41,26,'Birgitta Melin','ACCEPTED','Vi är anmälda via Marie men ville skriva ang allergi','tål inte vin, inte i maten heller','SPEX','Vän till Emils familj','10-15 min','nej, ev mick beroende på lokalen , har med egen gitarr','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(42,26,'Peter Melin','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(43,27,'Andreas Fridlund','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(44,28,'Alexander Gryth','DECLINED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(45,29,'Rickard Person','DECLINED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(46,29,'Linda Vergili','DECLINED','Rikards bästa kompis gifter sig samma datum :(',NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(47,30,'Fredrik Hagström','ACCEPTED','','','DECLINED','Vän.','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(48,31,'Niclas Rydhé','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(49,31,'Alva Nyström','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(50,32,'Sanna Thufvesson','ACCEPTED',NULL,'Ostbågar','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(51,33,'Vanja Wiberg','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(52,33,'Bertil Wiberg','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(53,34,'Kerstin Gustavsson','ACCEPTED','','','SPEACH','Josephines mormor','2 min','nej','tillsammans 4 min','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(54,34,'Ingemar Gustavsson','ACCEPTED','','','SPEACH','Josephines morfar','2 min','nej','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(55,35,'Christian Rosendahl','ACCEPTED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(56,35,'Charlotta Rosendahl','ACCEPTED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(57,35,'Melvin Rosendahl','ACCEPTED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(58,36,'Magdalena Fråhn','ACCEPTED','Vi längtar','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(59,36,'Robert Fråhn','ACCEPTED','Det ska bli roligt detta!','Nä, inte så farligt. ','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(60,37,'Ingemar Eckeskog','DECLINED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(61,37,'Catharina Eckeskog','DECLINED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(62,38,'Petra Andersson','ACCEPTED','Ser fram emot denna dag :)','-','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(63,38,'Mikael Andersson','ACCEPTED',' :)','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(64,39,'Glenn Stolt','ACCEPTED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(65,39,'Susanne Stolt','ACCEPTED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(66,40,'Lena Strömberg','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(67,40,'Daniel Strömberg','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(68,41,'Marie Andersson','ACCEPTED',NULL,'','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(69,41,'Urban Andersson','ACCEPTED',NULL,'','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(70,42,'Pia Nyberg','ACCEPTED','Tack för inbjudan!','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(71,42,'Mikael Nyberg','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(72,43,'Erica Petterson','ACCEPTED',NULL,'','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(73,43,'Michael Johansson','ACCEPTED',NULL,'','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(74,44,'Isabella Persson','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(75,45,'Linnéa Larsson','ACCEPTED','','Vegetarian men äter fisk','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(76,46,'Sara Johansson','DECLINED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(77,47,'Sara Asmoarp','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(78,47,'Oskar Jönsson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(79,48,'Susanne Olsson','ACCEPTED','','Laktos och gluten','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(80,49,'Anna Nyborg','ACCEPTED','','Laktos, smör funkar','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(81,49,'Joel Lindén','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(82,50,'Tobias Hanson','ACCEPTED','Du borde valt mig istället Emil...','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(83,50,'Erika Hanson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(84,51,'Rebecca Rensfelt','ACCEPTED','Du borde valt mig istället Emil...','Gråt på vigseln.','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(85,51,'Andrée Rensfelt','ACCEPTED','','Kvalster.','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(86,52,'Johan Stenström','ACCEPTED','','Nötter, ej jordnötter','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(87,52,'Ida Stenström','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(88,53,'Emma McCormick','ACCEPTED','Looking forward to witness the day when you two become one, love you!','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(89,53,'John McCormick','ACCEPTED','Klart jag kommer! Står för underhållningen ;)','Vid för lång frånvaro från Emma bara..','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(90,54,'Mariell Nyman','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(91,54,'Sam Nyman','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(92,55,'Shadi Khosravinejad','ACCEPTED','We LOOOVE YOUUU','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(93,55,'Elvis Andersson','ACCEPTED','Microvågsugn','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(94,56,'Simon Andersson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(95,56,'Evelina Samuelsson','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(96,57,'Cristian Johansson','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(97,57,'Ida Johansson','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(98,58,'Daniel Flygare','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(99,58,'Linda Flygare','ACCEPTED','Tack snälla för inbjudan <3 det ska bli jättekul!','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(100,59,'Cornelia Andersson','ACCEPTED','vi ser fram emot erat fina bröllop!','','DECLINED','Vänner','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(101,59,'Martin Persson','ACCEPTED','ska bli skoj!','','DECLINED','Vänner','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(102,60,'Nils Olsson','ACCEPTED','Ledsen att jag är sen','Nej','DECLINED','Goda vänner!','','','Kan jag ändra denna info sedan?','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(103,61,'Lukas Andersson','ACCEPTED','Tack!','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(104,62,'Amanda Jonegård','ACCEPTED','','','SPEACH','Nara van till bruden men kanner Emil med!','vet annu inte','nej, elr en mic kanske?','puss pa er! Langtar till brollopet!!','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(105,62,'Edilberto Antonio Serrano Hernandez','DECLINED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(106,63,'Jakob Stolt','ACCEPTED','','','DECLINED','Vänner','7-10','Två stolar','En lek','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(107,63,'Hanne Otzen','ACCEPTED','','','SPEX','Vänner','7-10','Två stolar','En lek','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(108,64,'Filip Stenström','ACCEPTED','','kräftor. alla andra skaldjur går bra. ','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(109,64,'Maja Stenström','ACCEPTED','vad roligt detta ska bli!!!!','','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(110,65,'Cecilia Wiberg','ACCEPTED',NULL,'','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(111,65,'Magnus Wiberg','ACCEPTED',NULL,'','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(112,66,'Julia Wiberg','ACCEPTED',NULL,'','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(113,66,'Simon Persson','ACCEPTED',NULL,'','DECLINED','',NULL,NULL,NULL,'2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(114,67,'Alicia Wiberg','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(115,68,'Emil Lunnergård','ACCEPTED','','','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(116,68,'Josephine Wiberg','ACCEPTED','Hej min bästa älsk! tänk snart ska vi gifta oss, wiihoo!!','lök','DECLINED','','','','','2014-02-12 13:57:52','2014-02-12 13:57:52'),
	(117,69,'Cia Ipsen','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,NULL,NULL),
	(118,69,'Paul Ipsen','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,NULL,NULL),
	(119,24,'Jacob Weckfors','ACCEPTED','','','DECLINED','',NULL,NULL,NULL,NULL,NULL),
	(120,70,'Tomas Olsson','ACCEPTED','','-','DECLINED','',NULL,NULL,NULL,NULL,NULL),
	(121,70,'Caroline Olsson','ACCEPTED','Fantastiskt roligt!','-','DECLINED','',NULL,NULL,NULL,NULL,NULL),
	(122,72,'Karl Petter Hjelmer','ACCEPTED','Ska bli riktigt roligt!','','DECLINED','Nära kollega till Emil','','','',NULL,NULL),
	(123,72,'Anna Håkansson','ACCEPTED','','','DECLINED','Livskamrat till Emils kollega Karl Petter','','','',NULL,NULL),
	(124,67,'Mattias Wiborn','ACCEPTED','','','DECLINED','','','','',NULL,NULL),
	(125,12,'Alexander Ericsson','ACCEPTED',NULL,NULL,'DECLINED','',NULL,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `invite_members` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table invites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `invites`;

CREATE TABLE `invites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `user_level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `invites` WRITE;
/*!40000 ALTER TABLE `invites` DISABLE KEYS */;

INSERT INTO `invites` (`id`, `code`, `user_level`)
VALUES
	(1,'läsabok',3),
	(2,'toto',3),
	(3,'snowboard',1),
	(4,'isbjörnar',1),
	(5,'gitarr',1),
	(6,'skidor',1),
	(7,'skogen',1),
	(8,'fysik',1),
	(9,'kultur',1),
	(10,'fantasydrömmar',1),
	(11,'slagverk',1),
	(12,'nn07',1),
	(13,'nudie-jeans',1),
	(14,'bakakaka',1),
	(15,'chiliplantor',1),
	(16,'dahlia',1),
	(17,'potatisåker',1),
	(18,'energisystemteknik',1),
	(19,'prästost',1),
	(20,'vattenmelon',1),
	(21,'clementiner',1),
	(22,'binär',1),
	(23,'hantverk',1),
	(24,'fjällräven',1),
	(25,'hästsko',1),
	(26,'handboll',1),
	(27,'solglasögon',1),
	(28,'diskussioner',1),
	(29,'skägg',1),
	(30,'ölkorv',1),
	(31,'barfotalöpning',1),
	(32,'glass',1),
	(33,'jordgubbar',1),
	(34,'monamie',1),
	(35,'blåbärspaj',1),
	(36,'pinklady',1),
	(37,'mysbelysning',1),
	(38,'vinter',1),
	(39,'längdskidor',1),
	(40,'vattenskidor',1),
	(41,'ranunkel',1),
	(42,'mörkchoklad',1),
	(43,'simhallen',1),
	(44,'pyssel',1),
	(45,'åre',1),
	(46,'sum-sim',1),
	(47,'kebnekaise',1),
	(48,'hållbarutveckling',1),
	(49,'snö',1),
	(50,'foofighters',1),
	(51,'apple',1),
	(52,'pannkakor',1),
	(53,'pick-nick',3),
	(54,'solsemester',3),
	(55,'grekland',1),
	(56,'musik',1),
	(57,'promenad',1),
	(58,'avokado',1),
	(59,'hallonsylt',1),
	(60,'lol-kingdom',1),
	(61,'dat-swag',1),
	(62,'bridesmaid',1),
	(63,'9cheeseburgers',1),
	(64,'miljötänk',1),
	(65,'skidsemester',3),
	(66,'mjölk',1),
	(67,'fotografier',1),
	(68,'älsk',5),
	(69,'köttbullar',1),
	(70,'ostbågar',1),
	(71,'gäst',0),
	(72,'symlänkar',1);

/*!40000 ALTER TABLE `invites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table items
# ------------------------------------------------------------

DROP TABLE IF EXISTS `items`;

CREATE TABLE `items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `invite_id` int(11) DEFAULT NULL,
  `section` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `booked` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;

INSERT INTO `items` (`id`, `invite_id`, `section`, `title`, `text`, `url`, `booked`)
VALUES
	(1,43,'MISC','Eva Solo dricksglas (6-pack)','','https://www.cervera.se/Pa-Bordet/Glas/Dricksglas/eva-solo-dricksglas-25-cl-6-pack',1),
	(2,6,'MISC','Eva Solo dricksglas (6-pack)','','https://www.cervera.se/Pa-Bordet/Glas/Dricksglas/eva-solo-dricksglas-25-cl-6-pack',1),
	(3,41,'MISC','Gjutjärnsgryta Skeppshult 4l','','https://www.cervera.se/Till-Koket/GrytorKastruller/Gjutjarnsgrytor/skeppshult-gjutjarnsgryta-4l-m-lock',1),
	(4,55,'MISC','Fondueset','','',1),
	(5,34,'MISC','Webergrill, Smokey Joe, svart','','http://www.icahemma.se/barbar-grill-37-cm-smokey-joe-gold-weber-p-20611.aspx?utm_source=prisjakt&utm_medium=cpc&utm_campaign=prisjakt',1),
	(6,36,'MISC','Kaffekvarn, Krups','','http://www.elgiganten.se/product/hem-och-hushall/kaffetillbehor/GVX242/krups-kaffekvarn-gvx242',1),
	(7,30,'MISC','Stavmixer, Philips HR1372','','http://www.tretti.se/hushallsapparater/mixers_och_vispar/stavmixers/philips-hr1372',1),
	(8,44,'MISC','Elvisp, Bosch MFQ4020','','http://www.clasohlson.com/se/Elvisp-Bosch-MFQ-4020/34-9772',1),
	(9,1,'MISC','Köksassistent Ankarsrum Assistent AKM6220 Original (svart, matt)','','http://assistent-original.se/produkt/akm-6220b-assistent-original/',1),
	(10,8,'MISC','Knivset, Anders Petter, Stenfors 3 delar (finns på Cervera)','','http://s3.pji.nu/product/standard/800/2641538.jpg',1),
	(11,66,'MISC','Wokpanna till grillen','','',1),
	(12,54,'MISC','Brassestolar, 2 st','','',1),
	(13,67,'MISC','Palettkniv','','',1),
	(14,47,'MISC','Utflyktsfilt','','',1),
	(15,72,'MISC','Kabinväska (mjuk)','','',1),
	(16,31,'MISC','Margrethe Mixkanna 1l (Azur, Lavendel eller Gul)','','https://www.cervera.se/Till-Koket/Baka/Beredningsskalar/margrethe-mixkanna-1l-33245-1',1),
	(17,34,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(18,34,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(19,34,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(20,34,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(21,34,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(22,34,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(23,41,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(24,41,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(25,37,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(26,37,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(27,37,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(28,37,'MATTALLRIK','Mattallrik, Pillivuyt 26cm Sancerre','','https://www.cervera.se/Pa-Bordet/Tallrikar/Flata-tallrikar/sancerre-tallrik-26cm',1),
	(29,71,'MISC','Resväska, lättvikt (minst 70cm hög)','','',0),
	(30,NULL,'MISC','Resväska, lättvikt (minst 70cm hög)','','',0),
	(31,19,'MISC','Stenfors grönsakskniv (finns på Cervera)','','',1),
	(32,58,'MISC','Stenfors santokukniv (finns på Cervera)','','',0),
	(33,3,'MISC','Minosharp knivslip (3 hjul)','','https://www.cervera.se/Till-Koket/Koksknivar/Knivtillbehor/minosharp-knivslip-3-hjul',1),
	(34,14,'MISC','Stekpanna 28cm (ska fungera med induktionshäll)','','',1),
	(35,14,'MISC','Digital stektermometer med kabeln in i ugnen','','',1),
	(36,3,'MISC','Rund baksten','','',1),
	(37,46,'MISC','Prenumeration på Residence','','http://www.tidningsbutiken.se/inredning/residence',1),
	(38,71,'MISC','Moccamaster Clubline KB741 A0',NULL,'http://www.moccamaster.com/se/brewers/product/59671/kb741-ao-white-metallic/',1);

/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
